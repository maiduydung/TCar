/*
 *		usermian.c
 *		User Main
 */
#include <tm/tmonitor.h>

EXPORT INT usermain( void )
{
	tm_printf("hello, world\n");

	return 0;
}
